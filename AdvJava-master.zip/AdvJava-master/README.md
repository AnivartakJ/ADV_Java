## Advanced Java - Codes

This repo contains codes for the course - Advanced Java

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files are generated in the `bin` folder by default.