package Apr06.InheritanceInIterfaces;

public class Main {
    public static void main(String[] args) {
        // Interface can extend another interface
        // Example: see other two files
    }
}
