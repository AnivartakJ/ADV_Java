package Apr06.InheritanceInIterfaces;

public interface PizzaSimple {
    
}
