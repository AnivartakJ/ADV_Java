package Apr06.InheritanceInIterfaces;

public interface PizzaComplex extends PizzaSimple {
    
}
