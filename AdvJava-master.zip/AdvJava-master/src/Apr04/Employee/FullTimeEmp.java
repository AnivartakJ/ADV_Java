package Apr04.Employee;

public class FullTimeEmp extends Employee{

    @Override
    public String getStatus() {
        return "Full Time";
    }    
}
