package Apr04.Employee;

public abstract class Employee {
    public abstract String getStatus();
}
