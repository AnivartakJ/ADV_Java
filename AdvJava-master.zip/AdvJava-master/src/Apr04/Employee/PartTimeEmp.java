package Apr04.Employee;

public class PartTimeEmp extends Employee{
    @Override
    public String getStatus() {
        return "Part Time";
    }    
}
