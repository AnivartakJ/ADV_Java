package Apr04;

public final class FinalClass {
    // after using 'final' keyword, this class cannot be inherited
}
