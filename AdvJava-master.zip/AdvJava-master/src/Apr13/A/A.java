package Apr13.A;

public class A {
    public static void greet(){
        System.out.println("Jay Shree Ram from class A in package A");
    }
}
